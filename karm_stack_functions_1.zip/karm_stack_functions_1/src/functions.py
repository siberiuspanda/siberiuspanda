"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
""" 
from Stack_array import Stack


#T01
def stack_split_alt(source):
    """
    -------------------------------------------------------
    Splits the source stack into separate target stacks.
    When finished source stack is empty. Values are
    pushed alternately onto the returned target stacks.
    Use: target1, target2 = stack_split_alt(source)
    -------------------------------------------------------
    Parameters:
        source - the stack to split into two parts (Stack)
    Returns:
        target1 - contains alternating values from source (Stack)
        target2 - contains other alternating values from source (Stack)
    -------------------------------------------------------
    """
    target1 = Stack()
    target2 = Stack()
    
    while source.is_empty() != True: 
        target1.push(source.pop())
        if source.is_empty() == False :
            target2.push(source.pop())
    return target1, target2

#T03
def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    result = []
    
    while source.is_empty() == False :
        result.append(source.pop())
        
    while len(result) > 0 :
        source.push(result.pop(0))
        
    return

#T05
# Constants
OPERATORS = "+-*/"

def postfix(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = postfix(string)
    -------------------------------------------------------
    Parameters:
        string - the postfix string to evaluate (str)
    Returns:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """
    stack = Stack()
   
    for check_item in string.split(' '):
      
        if check_item.isdigit():
            stack.push(int(check_item))

       
        elif check_item in OPERATORS:
            number_right = stack.pop()
            number_left = stack.pop()
            if check_item == '+':
                result = number_left + number_right
                stack.push(result)
            elif check_item == '-':
                result = number_left - number_right
                stack.push(result)
            elif check_item == '*':
                result = number_left * number_right
                stack.push(result)
            elif check_item == '/':
                result = number_left / number_right
                stack.push(result)

    answer = stack.pop()
    return answer

#T06
def reroute(opstring, values_in):
    """
    -------------------------------------------------------
    Reroutes values in a list according to a operating string and
    returns a new list of values. values_in is unchanged.
    In opstring, 'S' means push onto stack,
    'X' means pop from stack into values_out.
    Use: values_out = reroute(opstring, values_in)
    -------------------------------------------------------
    Parameters:
        opstring - String containing only 'S' and 'X's (str)
        values_in - A valid list (list of ?)
    Returns:
        values_out - if opstring is valid then values_out contains a
            reordered version of values_in, otherwise returns
            None (list of ?)
    -------------------------------------------------------
    """
    values_out = []
    stack = Stack()
    
    for char in opstring:
        if char == 'S':
            
            if(len(values_in)==0):
                return None
            else:
                stack.push(values_in.pop(0))
        else:
            if(stack.is_empty()) == True :
                return None
            else:
                values_out.append(stack.pop())
    return values_out
            
#T07
# Imports
from enum import Enum

# Enumerated constant
MIRRORED = Enum('MIRRORED',
                {'IS_MIRRORED': "is a mirror", 'TOO_MANY_LEFT': "too many characters in L",
                 'TOO_MANY_RIGHT': "too many characters in R", 'MISMATCHED': "L and R don't match",
                 'INVALID_CHAR': "invalid character", 'NOT_MIRRORED': "no mirror character"})

def is_mirror_stack(string, valid_chars, m):
    """
    -------------------------------------------------------
    Determines if string is a mirror of characters in valid_chars around the pivot m.
    A mirror is of the form LmR, where L is the reverse of R, and L and R
    contain only characters in valid_chars.
    Use: mirror = is_mirror_stack(string, valid_chars, m)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
        valid_chars - a string of valid characters (str)
        m - the mirror pivot string (str - one character not in valid_chars)
    Returns:
        mirror - the state of the string (Enum MIRRORED)
    -------------------------------------------------------
    """
    assert m not in valid_chars, \
        "cannot use '{}' as the mirror character".format(m)
    
    stack = Stack()
    left = 0
    right = 0
    value = True 
    mirror = "None"

    if m not in string:
        mirror = MIRRORED.NOT_MIRRORED
        value = False 

    while value == True and left < len(string) and string[left] != m:
        if string[left] in valid_chars:
            stack.push(string[left])
            left += 1
        else:
            mirror = MIRRORED.INVALID_CHAR
            value = False 
            left += 1

    if value == True: 
        final_left = left
        left += 1
        while left < len(string) and not stack.is_empty() and value == True:
            value = stack.pop()
            if string[left] == value:
                left += 1
                right += 1
                value = True
            elif string[left] != value:
                mirror = MIRRORED.MISMATCHED
                value = False
        while left < len(string) and len(string) > 0:
            left += 1
            right += 1

        if right > final_left and value == True:
            mirror = MIRRORED.TOO_MANY_RIGHT
        elif final_left > right and value == True:
            mirror = MIRRORED.TOO_MANY_LEFT
        elif value == True and final_left == right:
            mirror = MIRRORED.IS_MIRRORED
    return(mirror)