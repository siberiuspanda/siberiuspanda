"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from functions import reroute
from Stack_array import Stack

stack = Stack()


opstring = 'SSXSSXXX'

values_in = [1,2,3,4]

print('Initial Positions: {}'.format(values_in))

values_out = reroute(opstring, values_in)

print(values_out)