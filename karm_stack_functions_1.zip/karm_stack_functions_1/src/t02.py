"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from Stack_array import Stack

source = Stack()
test_list = [8, 14, 12, 9, 8, 7, 5]
for x in test_list:
    source.push(x)
target1, target2 = source.split_alt()

print('Original: {}'.format(test_list))
print('Target One: {}'.format(target1._values))
print('Target Two: {}'.format(target2._values))