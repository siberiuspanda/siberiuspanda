"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from functions import is_mirror_stack

mirror = is_mirror_stack("acamacba", "abc", "m")
print("Inputted String {}".format(mirror.value))