"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from functions import postfix
from Stack_array import Stack

z = Stack()

string = '4 5 + 12 * 2 3 * -'

answer = postfix(string)

print('The postfix expression {} evaluates to {}'.format(string,answer))

string = '12 5 -'

answer = postfix(string)

print('The postfix expression {} evaluates to {}'.format(string,answer))