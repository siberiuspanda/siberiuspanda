"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from Stack_array import Stack

stack = Stack()
list_test = list(range(10))
print("Original Stack: {}".format(list_test))

while len(list_test) > 0:
    stack.push(list_test.pop())
stack.reverse()


while stack.is_empty() == False:
    list_test.append(stack.pop())
print("Reversed Stack: {}".format(list_test))