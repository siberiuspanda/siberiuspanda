"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-02-05"
-------------------------------------------------------
"""
from functions import stack_reverse
from Stack_array import Stack

stack = Stack()
test_data = list(range(10))
print("Original Stack: {}".format(test_data))

while len(test_data) > 0:
    stack.push(test_data.pop())
stack_reverse(stack)

while not stack.is_empty():
    test_data.append(stack.pop())
print("Reversed Stack: {}".format(test_data))