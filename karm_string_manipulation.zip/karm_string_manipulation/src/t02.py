"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-21"
-------------------------------------------------------
"""
from functions import clean_list

values = [0, 1, 2, 3, 4, 5, 5, 5, 6, 6, 7, 8, 8, 9, 9, 0]

clean_list(values)

print(values)