"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-22"
-------------------------------------------------------
"""
from functions import matrixes_multiply

a = [[1, 4], [2, 5], [3, 6]]
b = [[10, 20, 30], [11, 21, 31]]

c = matrixes_multiply(a, b)

print("{}".format(c))