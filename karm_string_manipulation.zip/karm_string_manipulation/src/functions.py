"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-15"
-------------------------------------------------------
"""
LOWER_CASE_VOWELS = ['a','e','i','o','u']
UPPER_CASE_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#T01
def is_leap_year(year):
    """
    -------------------------------------------------------
    Leap year determination.
    Use: leap_year = is_leap_year(year)
    -------------------------------------------------------
    Parameters:
        year - year to determine if it is a leap year (int > 0)
    Returns:
        leap_year - True if year is a leap year, False otherwise (boolean)
    -------------------------------------------------------
    """
    leap_year = False
    if year % 100 == 0:
        if year % 400 == 0:
            leap_year = True 
    elif year % 4 == 0:
        leap_year = True 
    else: 
        leap_year = False 
    return leap_year

#T02
def clean_list(values):
    """
    -------------------------------------------------------
    Removes all duplicate values from a list: values contains
    only one copy of each of its integers. The order of values
    must be preserved.
    Use: clean_list(values)
    -------------------------------------------------------
    Parameters:
        values - a list of integers (list of int)
    Returns:
        None
    -------------------------------------------------------
    """
    x = 0
    while x < len(values):
        y = x + 1
        while y < len(values):
            if values[x] == values[y]:
                values.pop(y)
            else:
                y += 1
        x += 1

    return

#T03
def matrix_transpose(a):
    """
    -------------------------------------------------------
    Transpose the contents of matrix a.
    Use: b = matrix_transpose(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list (list of lists of ?)
    Returns:
        b - the transposed matrix (list of lists of ?)
    -------------------------------------------------------
    """
    
    empty_list = []
    index = 0
    for component in a[0]:
        empty_list.append([component, a[1][index]])
        index += 1
    
    return empty_list
        
#T04
def matrixes_multiply(a, b):
    """
    -------------------------------------------------------
    Multiplies the contents of matrixes a and b.
    If a is mxn in size, and b is nxp in size, then c is mxp.
    a and b must be unchanged.
    Use: c = matrixes_multiply(a, b)
    -------------------------------------------------------
    Parameters:
        a - a 2D list (2D list of int/float)
        b - a 2D list (2D list of int/float)
    Returns:
        c - the matrix multiple of a and b (2D list of int/float)
    -------------------------------------------------------
    """
    row1 = len(a)
    col1 = len(a[0])
    c = []

    for x in range(row1):
        row = []
        y = 0
        for y in range(row1):
            product = 0
            for z in range(col1):
                product = product + (a[x][z] * b[z][y])
            row.append(product)
        c.append(row)
    return c

#T05
def file_analyze(fv):
    """
    -------------------------------------------------------
    Analyzes the characters in a file.
    The contents of the file must be unchanged.
    Use: u, l, d, w, r = file_analyze(fv)
    -------------------------------------------------------
    Parameters:
        fv - an already open file reference (file variable)
    Returns:
        u - the number of uppercase letters in the file (int)
        l - the number of lowercase letters in the file (int)
        d - the number of digits in the file (int)
        w - the number of whitespace characters in the file (int)
        r - the number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    u = 0 
    l = 0 
    d = 0 
    w = 0 
    r = 0 
    for line in fv:
        for i in line:
            if i.isupper():
                u += 1
            elif i.islower():
                l += 1
            elif i.isdigit():
                d += 1
            elif i.isspace():
                w += 1
            else: 
                r += 1
    return u, l, d, w, r 

#T06
def dsmvwl(s):
    """
    -------------------------------------------------------
    Disemvowels a string. out contains all the characters in s
    that are not vowels. ('y' is not considered a vowel.) Case is preserved.
    Use: out = dsmvl(s)
    -------------------------------------------------------
    Parameters:
       s - a string (str)
    Returns:
       out - s with the vowels removed (str)
    -------------------------------------------------------
    """
    
    out = ''
    
    for v in s:
        if v.lower() in LOWER_CASE_VOWELS:
            s = s.replace(v, '')
            out = s
    return out

#T07
def substitute(string, ciphertext):
    """
    -------------------------------------------------------
    Encipher a string using the letter positions in ciphertext.
    Only letters are enciphered, and the returned string is
    in upper case.
    Use: estring = substitute(string, ciphertext):
    -------------------------------------------------------
    Parameters:
        string - string to encipher (str)
        ciphertext - ciphertext alphabet (str)
    Returns:
        estring - the enciphered string (str)
    -------------------------------------------------------
    """
    new_string = string.upper()
    estring = ""
    for letter in new_string:
        if letter.isalpha():
            letter_index = UPPER_CASE_LETTERS.index(letter)
            estring += ciphertext[letter_index]
        else:
            estring += letter
    return estring

#T08
def shift(string, n):
    """
    -------------------------------------------------------
    Encipher a string using a shift cipher.
    Only letters are enciphered, and the returned string is
    in upper case.
    Use: estring = shift(string, n):
    -------------------------------------------------------
    Parameters:
        string - string to encipher (str)
        n - the number of letters to shift (int)
    Returns:
        estring - the enciphered string (str)
    -------------------------------------------------------
    """   
    string = string.upper()
    ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    estring = ''

    for x in string:
        if x.isalpha():
            location = ALPHA.index(x)
            position = (location + n) % 26
            estring += ALPHA[position]
        else:
            estring += x

    return estring



        
            
        