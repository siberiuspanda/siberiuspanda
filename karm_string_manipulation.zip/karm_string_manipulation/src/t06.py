"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-22"
-------------------------------------------------------
"""
from functions import dsmvwl

s = input('Enter a sentence of your choice: ')

out = dsmvwl(s)

print("Disemvowelled: {}".format(out))