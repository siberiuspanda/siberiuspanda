"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-22"
-------------------------------------------------------
"""
from functions import substitute   
    
file = open("pelee.txt", "r")
final_text = open("substitute.txt", "w")
text = file.read()

cipher = "DAVIBROWNZCEFGHJKLMPQSTUXY"
output = substitute(text, cipher)

final_text.write(output)


file.close()
final_text.close()