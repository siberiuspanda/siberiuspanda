"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-15"
-------------------------------------------------------
"""
from functions import matrix_transpose

a = [[0, 2, 4, 6, 8], [1, 3, 5, 7, 9]]

list = matrix_transpose(a)
print("{}".format(list)) 