"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-22"
-------------------------------------------------------
"""
from functions import file_analyze

fv = open("test.txt", "r")

u, l, d, w, r = file_analyze(fv)

print('There are {} uppercase letters, {} lowercase letters, {} digits, {} whitespaces and {} other characters in this file.'.format(u,l,d,w,r))