"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-22"
-------------------------------------------------------
"""
from functions import shift

file = open("pelee.txt", "r")
n = int(input('How many n positions shift to the right: '))
new_file = open("shift.txt", "w")
string = file.read()


estring = shift(string, n)

new_file.write(estring)

file.close()
new_file.close()