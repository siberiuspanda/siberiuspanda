"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-01-15"
-------------------------------------------------------
"""
from functions import is_leap_year

year = int(input('Enter year to test: '))

leap_year = is_leap_year(year)

print('{}'.format(leap_year))


