
"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
from functions import falling_distance

#Input
seconds = int(input('Enter the falling time (in secs): '))

#Calculate
distance = falling_distance(seconds)

#Output
print('The Object has falling {:.2f} meters in {} seconds.'.format(distance,seconds))

