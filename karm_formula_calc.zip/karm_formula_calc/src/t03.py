"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
#import function
from functions import convert_date

#Input
date_int = int(input('Enter a date in the format MMDDYYYY: '))

#Call on Function
day,month,year = convert_date(date_int)

#Output
print('{:02d}/{:02d}/{:04d}'.format(day,month,year))
