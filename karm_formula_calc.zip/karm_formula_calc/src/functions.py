"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
#CONSTANTS
GRAVITY_CONSTANT = 9.8
DAYS = 86400
HOURS = 3600
MINUTES = 60

#T01
def falling_distance(seconds):
    """
    -------------------------------------------------------
    Calculates and returns the falling distance of an object, in meters, in a time interval.
    Use: distance = falling_distance(seconds)
    -------------------------------------------------------
    Parameters:
        seconds - falling time (float >= 0)
    Returns:
        distance - distance, in meters, fallen (float)
    ------------------------------------------------------
    """
    distance = float(0.5*GRAVITY_CONSTANT*(seconds**2))
    return distance

#T02
def calorie_calculator(fat_grams,carb_grams):
    """
    -------------------------------------------------------
    Calculates and returns the falling distance of an object, in meters, in a time interval.
    Use: distance = falling_distance(seconds)
    -------------------------------------------------------
    Parameters:
        fat_grams - number of fat grams consumed in a day (float >= 0)
        carb_grams - number of carbohydrate grams consumed in a day (float >= 0)
    Returns:
        fat_calories - resulting calories from fat grams consumed (float)
        carb_calories - resulting calories from carbohydrate grams consumed (float)
        total_calories - the total amount of calories consumed (float)
    ------------------------------------------------------
    """
    fat_calories = 9*fat_grams
    carb_calories = 4*carb_grams
    total_calories = fat_calories+carb_calories
    return fat_calories,carb_calories,total_calories

#T03
def convert_date (date_int):
    """
    -------------------------------------------------------
    Converts date_int into days, month and year
    Use: day,month,year = convert_date (date_int)
    -------------------------------------------------------
    Parameters:
        date_int - (int > 0)
    Returns:
        day: the day in the month in date_int (in t>= 0)
        month: the month in date_int(int >=0)
        year: the years in date_int(int >=0)
    ------------------------------------------------------
    """
    day = (date_int//10000)%100
    month = date_int//1000000
    year = date_int%10000
    return day,month,year

#T04
def convert_sec (num_sec):
    """
    -------------------------------------------------------
    Converts num_sec into days, hours, minutes and seconds
    Use: days,hours,minutes, seconds = convert_sec (num_sec)
    -------------------------------------------------------
    Preconditions:
        num_sec - (int > 0)
    Returns:
        days: the number of days in num_sec (int >= 0)
        hours: number of hours in num_sec (int >= 0)
        minutes: number of minutes in num_sec (int >= 0)
        seconds: number of minutes in num_sec (int >= 0)
    ------------------------------------------------------
    """
    days = num_sec // (DAYS)
    seconds_per_hour = num_sec % (DAYS)
    hours = seconds_per_hour // HOURS
    num_sec %= HOURS
    minutes = num_sec // MINUTES
    num_sec %= MINUTES
    seconds = num_sec
    return days,hours,minutes,seconds

#T05
def math_quiz ():
    """
    -------------------------------------------------------
    Displays two random numbers to be added and compared to user answer
    Use: days,hours,minutes, seconds = convert_sec (num_sec)
    ------------------------------------------------------
    """
    import random
    num1 = random.randint(0,999)
    num2 = random.randint(0,999)
    sum_of_num = int(num1+num2)
    user_answer = int(input("""  {}
+ {}
""".format(num1,num2)))
    print("""
Your answer: {:,.0f}, it should be: {:,.0f}""".format(user_answer,sum_of_num))
    return num1,num2,sum_of_num
    