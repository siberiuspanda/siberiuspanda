"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
#import function
from functions import convert_sec

#input
num_sec = int(input('Enter number of seconds: '))

#Call Function
days,hours,minutes,seconds = convert_sec(num_sec)

#Display output
print('There are {} days, {} hours, {} minutes, and {} seconds in {} seconds'.format(days,hours,minutes,seconds,num_sec))