"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
#Import Function
from functions import math_quiz

math_quiz()