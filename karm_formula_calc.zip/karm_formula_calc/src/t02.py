"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-10-10"
-------------------------------------------------------
"""
#Import Function
from functions import calorie_calculator

#Input
fat_grams = int(input('Enter the fat grams consumed: '))
carb_grams = int(input('Enter the carbohydrate grams consumed: '))

#Call Function and Calculate
fat_calories, carb_calories, total_calories = calorie_calculator(fat_grams, carb_grams)

#Output
print("""
Fat calories: {}
Carb calories: {}
Total calories: {}""".format(fat_calories,carb_calories,total_calories))
