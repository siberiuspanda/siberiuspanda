"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-15"
-------------------------------------------------------
"""
#T01
def read_positive():
    """
    -------------------------------------------------------
    Asks the user for a series of numbers and returns a list of numbers 
    where only the positive numbers are kept
    Use: positive_list = read_positive()
    -------------------------------------------------------
    Parameters:
    Returns:
        positive_list - a list of positive integers
    -------------------------------------------------------
    """
    positive_list = []
    NUMBER = 1
    while NUMBER != 0:
        NUMBER = int(input('Enter a positive number: '))
        if NUMBER > 0 :
            positive_list.append(NUMBER)
    return positive_list

#T02
def find_target(LIST, target):
    """
    -------------------------------------------------------
    Finds the locations of a target value in a list 
    Use: location = find_target(LIST, target)
    -------------------------------------------------------
    Parameters:
        LIST - user inputed list
        target - target value
    Returns:
        location - list of locations of target number
    -------------------------------------------------------
    """
    location = []
    for x in range (len(LIST)):
        if target == LIST[x] :
            location.append(x)
    return location

#T03
def largest_odd(POSITIVE_LIST):
    """
    -------------------------------------------------------
    Prints the largest odd integer in the inputed list 
    Use: LARGE_ODD = largest_odd(POSITIVE_LIST)
    -------------------------------------------------------
    Parameters:
        POSITIVE_LIST - user inputed list
    Returns:
        LARGE_ODD - the largest odd integer in the input
    -------------------------------------------------------
    """
    LARGE_ODD = -1
    COUNT = 0
    while COUNT < len(POSITIVE_LIST):
        if POSITIVE_LIST[COUNT] % 2 != 0:
            if POSITIVE_LIST[COUNT] > LARGE_ODD:
                LARGE_ODD = POSITIVE_LIST[COUNT]
        COUNT = COUNT + 1

    return LARGE_ODD
#T04
def reverse_list(POSITIVE_LIST):
    """
    -------------------------------------------------------
    Reverse the given list 
    Use: reverse_list(POSITIVE_LIST)
    -------------------------------------------------------
    Parameters:
        POSITIVE_LIST - user inputed list
    Returns:
    -------------------------------------------------------
    """
    x = 0
    y = len(POSITIVE_LIST)-1
    while x < y:
        POSITIVE_LIST[x] = POSITIVE_LIST[y]
        POSITIVE_LIST[y] = POSITIVE_LIST[x]
        x += 1
        y -= 1
    return 