"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-15"
-------------------------------------------------------
"""
#IMPORT FUNCTION
from functions import read_positive

#CALL FUNCTION
POSITIVE_LIST = read_positive()

#OUTPUT
print("""
List entered: {}""".format(POSITIVE_LIST))

#IMPORT FUNCTION
from functions import largest_odd

#CALL FUNCTION
LARGE_ODD = largest_odd(POSITIVE_LIST)

print('Largest odd: {}'.format(LARGE_ODD))
