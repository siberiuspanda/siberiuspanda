"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-03-02"
-------------------------------------------------------
"""
from copy import deepcopy
class Set:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty Set.
        Use: s = Set()
        -------------------------------------------------------
        Returns:
            Initializes an empty set.
        -------------------------------------------------------
        """
        # your code here
        
        self._values = []
    

        return

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the set is empty.
        Use: b = s.is_empty()
        -------------------------------------------------------
        Returns:
            True if the set is empty, False otherwise.
        -------------------------------------------------------
        """
    
        return len(self._values) == 0

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the size of the set.
        Use: n = len(s)
        -------------------------------------------------------
        Returns:
            the number of values in the set.
        -------------------------------------------------------
        """
        return len(self._values)

    def _linear_search(self, key):
        """
        -------------------------------------------------------
        Searches for the first occurrence of key in the set.
        Private helper method - used only by other ADT methods.
        Use: i = self._linear_search(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            i - the index of key in the set, -1 if key is not found (int)
        -------------------------------------------------------
        """

        # your code here
        
        i = 0
        
        found = False
        
        while found == False:
            if i > len(self._values) - 1:
                i = -1
                found = True
            elif key == self._values[i]:
                found = True
                
            i += 1
                
        return i - 1

    def insert(self, i, value):
        """
        -------------------------------------------------------
        Inserts value at the proper place in the set.
        Use: b = s.insert(i, value)
        -------------------------------------------------------
        Parameters:
            i - index value (int)
            value - a data element (?)
        Returns:
            inserted - True if the value was inserted at i, False otherwise.
                value is inserted at position i or appended to the end of the set
                if i > len(s) only if value is unique in the set (boolean)
        -------------------------------------------------------
        """
        # your code here
        inserted = False 
        
        while value not in self._values:
            if i > len(self._values) :
                self._values += [value]
            else:
                self._values[i] = value
                
            inserted = True

        return inserted

    def remove(self, key):
        """
        -------------------------------------------------------
        Finds, removes, and returns the value in the set that matches key.
        Use: value = s.remove( key )
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        # your code here
        x = self._linear_search(key)
        value = None
        
        if x != -1:
            value = self._values.pop(x)
            
        return value

    def find(self, key):
        """
        -------------------------------------------------------
        Finds and returns a copy of value in the set that matches key.
        Use: value = s.find( key )
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - a copy of the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        assert len(self._values) > 0, "Cannot find in an empty set"

        # your code here
        x = self._linear_search(key)
        value = None
        
        if x != -1:
            value = deepcopy(self._values[x])

        return value

    def peek(self):
        """
        -------------------------------------------------------
        Returns a copy of the first value in list.
        Use: value = s.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the first value in the set (?)
        -------------------------------------------------------
        """
        assert len(self._values) > 0, "Cannot peek at an empty set"

        
        value = deepcopy(self._values[0])
        return value

    def index(self, key):
        """
        -------------------------------------------------------
        Finds the location of the first occurrence of key in the set.
        Use: n = s.index( key )
        -------------------------------------------------------
        Parameters:
            key - a data element (?)
        Returns:
            i - the location of the full value matching key, otherwise -1 (int)
        -------------------------------------------------------
        """

        # your code here
        
        i = self._linear_search(key)
        
        return i


    def _valid_index(self, i):
        """
        -------------------------------------------------------
        Private helper method to validate an index value.
        Python index values can be positive or negative and range from
          -len(set) to len(set) - 1
        Use: assert self._valid_index(i)
        -------------------------------------------------------
        Parameters:
            i - an index value (int)
        Returns:
            True if i is a valid index, False otherwise.
        -------------------------------------------------------
        """
        n = len(self._values)
        return -n <= i < n-1