"""
-------------------------------------------------------
Linked version of the Set ADT.
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Section: CP164 B, C
__updated__ = "2020-04-11"
-------------------------------------------------------
"""
# Imports
from copy import deepcopy


class _Set_Node:
    def __init__(self, value, next_):
        """
        -------------------------------------------------------
        Initializes a Set node that contains a copy of value
        and a link to another Set node.
        Use: node = _Set_Node(value, next_)
        -------------------------------------------------------
        Parameters:
        value - value for node (?)
        next_ - another Set node (_Set_Node)
        Returns:
        a new _Set_Node object (_Set_Node)
        -------------------------------------------------------
        """
        self._value = deepcopy(value)
        self._next = next_
         
class Set:
    def __init__(self):
        """
        -------------------------------------------------------
        Efficiency: O(*)
        -------------------------------------------------------
        Initializes an empty Set.
        Use: set = Set()
        -------------------------------------------------------
        Returns:
        A new Set object (Set)
        -------------------------------------------------------
        """
        self._front = None
        self._count = 0

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the number of values in the Set.
        Use: n = len(set)
        O(n^2)
        -------------------------------------------------------
        Returns:
            the number of values in the Set (int)
        -------------------------------------------------------
        """
        return self._count
        

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the Set is empty.
        O(n^2)
        Use: b = set.is_empty()
        -------------------------------------------------------
        Returns:
            True if the Set is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._count == 0

    def add(self, value):
        """
        ---------------------------------------------------------
        Adds value to the end of the Set, allows only one copy of value.
        Use: inserted = set.add(value)
        O(n)
        -------------------------------------------------------
        Parameters:
            value - a comparable data element (?)
        Returns:
            True if value is inserted, False otherwise (boolean)
        -------------------------------------------------------
        """
        node = _Set_Node(value, None)
        inserted = False
        if self.is_empty():
            self._front = node
            self._count += 1
            inserted = True
        else:
            current = self._front
            previous = None
            while current is not None and current._value != value:
                previous = current 
                current = current._next
            if current is None:
                previous._next = node
                self._count += 1
                inserted = True
        
        return inserted
        
    def max(self):
        """
        ---------------------------------------------------------
        Use: value = source.max()
        -------------------------------------------------------
        Returns:
            value - a copy of max value in source
        -------------------------------------------------------
        """
        current = self._front
        value = deepcopy(current._value)
        while current is not None:
            if current._value >= value:
                value = deepcopy(current._value)
            current = current._next
        
        return value 
        
    def min(self):
        """
        ---------------------------------------------------------
        Use: value = source.min()
        -------------------------------------------------------
        Returns:
            value - a copy of min value in source
        -------------------------------------------------------
        """
        current = self._front
        value = deepcopy(current._value)
        while current is not None:
            if current._value <= value:
                value = deepcopy(current._value)
            current = current._next
        
        return value 

    def _linear_search(self, key):
        """
        -------------------------------------------------------
        Searches for the first occurrence of key in set.
        Private helper method.
        Use: prev, curr = self._linear_search(key)
        O(n)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            prev - pointer to the node prev to the node containing key (_setNode)
            curr - pointer to the node containing key (_setNode)
        -------------------------------------------------------
        """
        curr = self._front
        prev = None 
        
        while curr is not None and curr._value != key:
            prev = curr
            curr = curr._next
        
        if curr is None:
            prev = None
        
        return prev, curr
    
    '''
        count = 0
        current = self._front
        prev = None
        found = False
        while count < self._max_size and found == False:
            if current._value != key or current is None:
                prev = current
                current = current._next
                count += 1
            else:
                found = True
        
        if not found:
            prev = None
        
        return prev, current
                
        
        
    '''

    def find(self, key):
        """
        -------------------------------------------------------
        Finds and returns a copy of the first value in set that matches key.
        Use: value = lst.find(key)
        O(n)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - a copy of the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        _ , curr = self._linear_search(key)
        if curr is not None:
            value = deepcopy(curr._value)
        else:
            value = None
            
        
        return value

    def remove(self, key):
        """
        -------------------------------------------------------
        Finds, removes, and returns the value in set that matches key.
        Returns None if no matching value.
        Use: value = set.remove(key)
        O(n)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        prev, curr = self._linear_search(key)
        if curr is None:
            value = None
        else:
            value = curr._value
            prev._next = curr._next
            curr._next = None
            self._count -= 1
        
        return value

    def remove_front(self):
        """
        -------------------------------------------------------
        Efficiency: O(n log n)
        -------------------------------------------------------
        Removes first node in source and returns its value.
        Use: value = source.remove_front()
        -------------------------------------------------------
        Returns:
        value - first value in source (?)
        -------------------------------------------------------
        """
        if self._count == 1:
            value = self._front._value
            self._front = None
        else:
            temp = self._front
            value = temp._value
            self._front = temp._next
            temp._next = None
            
        self._count -= 1
            
        
        return value

    def __contains__(self, key):
        """
        ---------------------------------------------------------
        Determines if the Set contains key.
        Use: b = key in set
        O(n log n)
        -------------------------------------------------------
        Parameters:
            key - a comparable data element (?)
        Returns:
            True if the Set contains key, False otherwise.
        -------------------------------------------------------
        """
        _, curr = self._linear_search(key)
        
        return curr is not None

    def reverse(self):
        """
        -------------------------------------------------------
        Reverses the order of the elements in set.
        Use: source.reverse()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        previous = None
        current = self._front

        while current is not None:
            temp = current._next
            current._next = previous
            previous = current
            current = temp

        self._front = previous
        
        return 

    def split_th(self):
        """
        -------------------------------------------------------
        Splits source into two parts. target1 contains the first half,
        target2 the second half. curr set becomes empty.
        Uses Tortoise/Hare algorithm.
        Use: target1, target2 = source.split_th()
        -------------------------------------------------------
        Returns:
            target1 - a new set with >= 50% of the original set (Set)
            target2 - a new set with <= 50% of the original set (Set)
        -------------------------------------------------------
        """
        
        target1 = Set()
        target2 = Set()
        n = len(self)
        if n % 2 == 0:
            first_half = n//2
        else:
            first_half = n//2 + 1
        
        prev = None
        current = self._front
        
        for _ in range(first_half-1):
            prev = current 
            current = current._next
        
        if prev is not None:
            prev._next = None
        
        target1._count = first_half
        target1._front = self._front
        
        target2._count = n - first_half
        target2._front = current
        
        self._front = None
        self._count = 0 
        
        
        return target1, target2
            

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source sets into the curr target set.
        When finished, the contents of source1 and source2 are interlaced
        into target and source1 and source2 are empty.
        Order of source values is preserved.
        (iterative algorithm)
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - an linked set (Set)
            source2 - an linked set (Set)
        Returns:
            None
        -------------------------------------------------------
        """
        while source1._front is not None and source2._front is not None:
            self.add(source1._remove_front())
            self.add(source2._remove_front())
        while source1._front is not None:
            self.add(source1._remove_front())
        while source2._front is not None:
            self.add(source2._remove_front())
        
        return
    
    def _remove_front(self):
        """
        -------------------------------------------------------
        Efficiency: O(n log n)
        -------------------------------------------------------
        Removes first node in source and returns its value.
        Use: value = source.remove_front()
        -------------------------------------------------------
        Returns:
        value - first value in source (?)
        -------------------------------------------------------
        """
        if self._count == 1:
            value = self._front._value
            self._front = None
        else:
            temp = self._front
            value = temp._value
            self._front = temp._next
            temp._next = None
        self._count -= 1
            
        
        return value
    
    def intersection(self, source):
        """
        -------------------------------------------------------
        Efficiency: O(n log n)
        -------------------------------------------------------
        Returns a new set with only the values that appear in both
        self and source.
        Resulting order is not guaranteed.
        Use: target = self.intersection(source)
        -------------------------------------------------------
        Parameters:
        source - a set (Set)
        Returns:
        target - a set containing one copy of all the values
        that appear in both self and source (Set)
        -------------------------------------------------------
        Examples:
        (1,2,3) intersection (3,2,1) is (1,2,3)
        (1,2,3) intersection (4,5,6) is ()
        (1,2,3,4,5,6) intersection (0,2,4,6,8) is (2,4,6)
        -------------------------------------------------------
        """
        target = Set()
        current = self._front
        while current is not None:
            _, result = source._linear_search(current._value)
            if result is not None:
                target.add(current._value)
            current = current._next
    
        return target
         
    def union(self, source):
        """
         -------------------------------------------------------
         Efficiency: O(n log n)
         -------------------------------------------------------
         Returns a new set with copies of all values from self and
        source.
         Values may appear in target only once.
         Resulting order is not guaranteed.
         Use: target = self.union(source)
         -------------------------------------------------------
         Parameters:
         source - a set (Set)
         Returns:
         target - a set containing one copy of all the values
         of self and source (Set)
         -------------------------------------------------------
         Examples:
         (1,2,3) union (3,2,1) is (1,2,3)
         (1,2,3) union (4,5,6) is (1,2,3,4,5,6)
         (1,2,3,4,5,6) union (8,2,4,6,0) is (1,2,3,4,5,6,8,0)
         -------------------------------------------------------
         """
        target = Set()
        current = self._front
        while current is not None:
            _, result = target._linear_search(current._value)
            if result is None:
                target.add(deepcopy(current._value))
            current = current._next
            
        
        new_current = source._front
        while new_current is not None:
            _, result = target._linear_search(new_current._value)
            if result is None:
                target.add(deepcopy(new_current._value))
            new_current = new_current._next
            
        return target
         
         
    def difference(self, source):
        """
         -------------------------------------------------------
         Efficiency: O(n^2)
         -------------------------------------------------------
         Returns a set that contains the items that exist only in
         self and not in source.
         Resulting order is not guaranteed.
         Use: target = self.difference(source)
         -------------------------------------------------------
         Parameters:
         source - a set (Set)
         Returns:
         target - a set containing one copy of all the values
         in self that are not in source (Set)
         -------------------------------------------------------
         Examples:
         (1,2,3) difference (3,2,1) is ()
         (1,2,3) difference (4,5,6) is (1,2,3)
         (1,2,3,4,5,6) difference (0,2,4,6,8) is (1,3,5)
         -------------------------------------------------------
         """
        target = Set()
        current = self._front
        
        while current is not None:
            _, result = source._linear_search(current._value)
            _, new_result = target._linear_search(current._value)
            if result is None and new_result is None:
                target.add(deepcopy(current._value))
            current = current._next
        
        return target
        
    def symmetric_difference(self, source):
        """
         -------------------------------------------------------
         Efficiency: O(n log n)
         -------------------------------------------------------
         Returns a set that contains the items that exist in
         self or source, but not in both.
         Resulting order is not guaranteed.
         Use: target = self.symmetric_difference(source)
         -------------------------------------------------------
         Parameters:
         source - a set (Set)
         Returns:
         target - a set containing one copy of all the values
         in self and source but not in both (Set)
         -------------------------------------------------------
         Examples:
         (1,2,3) symetric_difference (3,2,1) is ()
         (1,2,3) symetric_difference (4,5,6) is (1,2,3,4,5,6)
         (1,2,3,4,5,6) symetric_difference (0,2,4,6,8) is
         (0,1,3,5,8)
         -------------------------------------------------------
         """
        target = Set()
        current = self._front
        
        while current is not None:
            _, result = source._linear_search(current._value)
            _, new_result = target._linear_search(current._value)
            if result is None and new_result is None:
                target.add(deepcopy(current._value))
            current = current._next
            
        new_current = source._front
        while new_current is not None:
            _, result = self._linear_search(new_current._value)
            _, new_result = target._linear_search(new_current._value)
            if result is None and new_result is None:
                target.add(deepcopy(new_current._value))
            new_current = new_current._next
        
        return target
         
    def issubset(self, source):
        """
         -------------------------------------------------------
         Efficiency: O(n)
         -------------------------------------------------------
         Determines if self is a subset of source. self is a subset
        of source
         if self contains all the values in source.
         Use: same = self.issubset(source)
         -------------------------------------------------------
         Parameters:
         source - a set (Set)
         Returns:
         subset - True if self contains all the values in
        source,
         otherwise False (boolean)
         -------------------------------------------------------
         Examples:
         () issubset (3,2,1) is True
         (1,2,3) issubset (3,2,1) is True
         (1,2,3) issubset (4,5,6) is False
         (2,4,6) issubset (0,2,4,6,8) is True
         -------------------------------------------------------
         """
         
        return
         
    def isdisjoint(self, source):
        """
         -------------------------------------------------------
         Efficiency: O(n)
         -------------------------------------------------------
         Determines if self is disjoint with source. self is
        disjoint with source
         if self and source have not values in common.
         Use: same = self.isdisjoint(source)
         -------------------------------------------------------
         Parameters:
         source - a set (Set)
         Returns:
         disjoint - True if self and source have not values in
        common,
         otherwise False (boolean)
         -------------------------------------------------------
         Examples:
         () isdisjoint (3,2,1) is True
         (1,2,3) isdisjoint (3,2,1) is True
         (1,2,3) isdisjoint (4,5,6) is False
         (2,4,6) isdisjoint (0,2,4,6,8) is True
         -------------------------------------------------------
         """
         
        return

    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the set
        from first to last items.
        Use: for v in set:
        -------------------------------------------------------
        Returns:
            yields
            value - the next value in the set (?)
        -------------------------------------------------------
        """
        curr = self._front

        while curr is not None:
            yield curr._value
            curr = curr._next