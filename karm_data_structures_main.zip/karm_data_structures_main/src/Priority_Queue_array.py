"""
-------------------------------------------------------
Array version of the Priority Queue ADT.
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Section: CP164 Spring 2019
__updated__ = "2019-05-31"
-------------------------------------------------------
"""
from copy import deepcopy


class Priority_Queue:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty priority queue.
        Use: pq = Priority_Queue()
        -------------------------------------------------------
        Returns:
            a new Priority_Queue object (Priority_Queue)
        -------------------------------------------------------
        """
        self._values = []
        self._first = None
        return

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the l ength of the priority queue.
        Use: n = len(pq)
        -------------------------------------------------------
        Returns:
            the number of values in the priority queue.
        -------------------------------------------------------
        """
        

        return len(self._values)

    def _set_first(self):
        """
        5 5 7 8 5 3 5
        -------------------------------------------------------
        Private helper function to set the value of _first.
        _first is the index of the value with the highest
        priority in the priority queue. None if queue is empty.
        Use: self._set_first()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        if len(self._values) > 0:
            a = self._values[-1]
            self._first = self._values.index(a)
            for i in self._values:
                if i < self._values[self._first]:
                    self._first = self._values.index(i)
        else:
            self._first = None
            
        return

    def combine(self, source1, source2):
        """
        
        -------------------------------------------------------
        Combines two source queues into the current target priority queue. 
        When finished, the contents of source1 and source2 are interlaced 
        into target and source1 and source2 are empty.
        (iterative algorithm)
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - an array-based priority queue (Priority_Queue)
            source2 - an array-based priority queue (priority)
        Returns:
            None
        -------------------------------------------------------
        """
        while len(source1._values) > 0 or len(source2._values) > 0 :
            if len(source1._values) > 0 and len(source2._values) == 0:
                self._values.append(source1._values.pop(0))
            elif len(source1._values) == 0 and len(source2._values) > 0 :
                self._values.append(source2._values.pop(0))
            else:
                self._values.append(source1._values.pop(0))
                self._values.append(source2._values.pop(0))
            
            source1._set_first()
            source2._set_first()
        
        
        self._set_first()

        return

    def insert(self, value):
        """
        -------------------------------------------------------
        A copy of value is appended to the end of the the priority queue
        Python list, and _first is updated as appropriate to the index of
        value with the highest priority.
        Use: pq.insert(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.append(deepcopy(value))
        
        if self._first == None :
            self._first = 0 
        elif self._values[self._first] > value:
            self._first = len(self._values) - 1

        return

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the priority queue is empty.
        Use: b = pq.is_empty()
        -------------------------------------------------------
        Returns:
            True if priority queue is empty, False otherwise.
        -------------------------------------------------------
        """
        

        return len(self._values) == 0

    def peek(self):
        """
        -------------------------------------------------------
        Peeks at the highest priority value of the priority queue.
        Use: v = pq.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the highest priority value in the priority queue -
                the value is not removed from the priority queue. (?)
        -------------------------------------------------------
        """
        assert (len(self._values) > 0), 'Cannot peek at an empty priority queue'

        value = deepcopy(self._values[self._first])

        return value

    def remove(self):
        """
        -------------------------------------------------------
        Removes and returns the highest priority value from the priority queue.
        Use: value = pq.remove()
        -------------------------------------------------------
        Returns:
            value - the highest priority value in the priority queue -
                the value is removed from the priority queue. (?)
        -------------------------------------------------------
        """
        assert (len(self._values) > 0), 'Cannot remove from an empty priority queue'

        value = self._values.pop(self._first)
        
        if len(self._values) == 0:
            self._first = None
        else:
            self._first= 0
            for x in range(len(self._values)):
                if self._values[x] < self._values[self._first]:
                    self._first = x

        return value
    
        '''
        value = self._values[self._first]
        
        if len(self._values) == 0:
            self._first = None
        else:
            self._first = 0
            for x in range(len(self._values)):
                if self._values[x] < self._values[self._first] :
                    self._first = x
        '''

    def split_alt(self):
        """
        -------------------------------------------------------
        Splits a priority queue into two with values going to alternating
        priority queues. The source priority queue is empty when the method
        ends. The order of the values in source is preserved.
        Use: target1, target2 = source.split_alt()
        -------------------------------------------------------
        Returns:
            target1 - a priority queue that contains alternating values
                from the current queue (Priority_Queue)
            target2 - priority queue that contains  alternating values
                from the current queue  (Priority_Queue)
        -------------------------------------------------------
        """
        target1 = Priority_Queue()
        target2 = Priority_Queue()
        x = True
        
        while self._values != []:
            if x == True:
                target1._values.append(self._values.pop(0))
            else:
                target2._values.append(self._values.pop(0))
            x = not x
        
            target1._set_first()
            target2._set_first()
        
        self._set_first()

        return target1, target2

    def split_key(self, key):
        """
        -------------------------------------------------------
        Splits a priority queue into two depending on an external
        priority key. The source priority queue is empty when the method
        ends. The order of the values from source is preserved.
        Use: target1, target2 = source.split_key(key)
        -------------------------------------------------------
        Parameters:
            key - a data object (?)
        Returns:
            target1 - a priority queue that contains all values
                with priority higher than key (Priority_Queue)
            target2 - priority queue that contains all values with
                priority lower than or equal to key (Priority_Queue)
        -------------------------------------------------------
        """
        target1 = Priority_Queue()
        target2 = Priority_Queue()
        while len(self._values) != 0 :
            for y in range(len(self._values)):
                if self._values[y] < key:
                    target1._values.append(self._values.pop(y))
                else:
                    target2._values.append(self._values.pop(y))
            
            target1._set_first()
            target2._set_first()
        self._set_first()
        
        
        return target1, target2

    def __iter__(self):
        """
        FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the priority queue
        from front to rear. Not in priority order.
        Use: for value in pq:
        -------------------------------------------------------
        Returns:
            value - the next value in the priority queue (?)
        -------------------------------------------------------
        """
        for value in self._values:
            yield value

