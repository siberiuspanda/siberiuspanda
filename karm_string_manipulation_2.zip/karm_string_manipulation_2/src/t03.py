"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
#IMPORT FUNCTION
from functions import find_frequent

#INPUT
my_str = input('Enter a string: ')

#CALL FUNCTION
frequent_char = find_frequent(my_str)

#OUTPUT
print('Most frequent characters: {}'.format(frequent_char))