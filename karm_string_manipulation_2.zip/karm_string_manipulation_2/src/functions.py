"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
#T01
def driver_license(student_answer, correct_answer):
    total_correct = 0
    total_incorrect = 0
    incorrect_answers = []
    
    for i in range(len(correct_answer)):
        if correct_answer[i] == student_answer[i]:
            total_correct += 1
        else:
            total_incorrect += 1
            incorrect_answers.append(i)
    return total_correct,total_incorrect,incorrect_answers

#T02
def sum_digit(my_str):
    """
    -------------------------------------------------------
    sums all the single digit numbers in my_str
    use: total = sum_digit(my_str)
    -------------------------------------------------------
    
    Parameters:
        my_str: string that has single-digit numbers (str)
    Returns: 
        total: sum of all the single digit number (integer >= 0)
    -------------------------------------------------------
    """
    total = 0
    
    for x in my_str:
        if x.isdigit() == True:
            new_str = int(x)
            total += new_str
    return total

#T03
def find_frequent(my_str):
    """
    -------------------------------------------------------
    finds the character that appears most frequently
    use: char = find_frequent(my_str)
    -------------------------------------------------------
    
    Parameters:
        my_str: (str)
    Returns: 
        frequent_char: most frequent character
    -------------------------------------------------------
    """
    frequent_char = ''
    count = 0
    for x in my_str:
        second_count = 0
        for y in my_str:
            if x == y :
                second_count += 1
        if second_count > count :
            frequent_char = x
            count = second_count
    return frequent_char
    
#T04
def add_spaces(my_str):
    """
    -------------------------------------------------------
    create a new string with added space between words
    use: new_str = add_spaces (my_str)
    -------------------------------------------------------
    Parameters:
        my_str: string that represents a sentence in which all the words
        are run together (no spaces), but the first character of each word
        is upper case
    Returns:
        new_str: new string in which the words are separated by 
        spaces and only the first word starts with an upper case character
    -------------------------------------------------------
    """
    list_str = []
    new_str = ''
    list_str.append(my_str[0])
     
    for i in my_str[1:]:
        if i.islower():
            list_str.append(i)
            
        elif i.isupper():
            list_str.append(" ")
            list_str.append(i.lower())
            
        else:
            list_str.append(i)
            
    for j in range(0, len(list_str)):
        new_str += list_str[j]  
    
    return new_str
    
    
#T05
def is_chain(list_string):
    """
    -------------------------------------------------------
    takes a list of words(list of strings) as parameter and returns True if the list contains a word chain and False otherwise.
    use: chain_check = is_chain(list_string)
    -------------------------------------------------------
    Parameters:
    list_string: a list of words that will be checked to see if it is a word chain
    Returns:
    chain_check: returns a true or false based on if the list is a word chain
    -----------------------------------------------------
    """    
    chain_check = False

    chain_check_list = []

    for x in range (len(list_string) - 1):
       
        use_str = []
        use_str_1 = []
        use_str[:0] = list_string[x]
        use_str_1[:0] = list_string[x + 1]

        if use_str[-1] == use_str_1[0]:
            chain_check_list.append(True)
        else:
            chain_check_list.append(False)

    if chain_check_list.count(True) == len(chain_check_list):
        chain_check = True

    return chain_check