"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
#IMPORT FUNCTION
from functions import add_spaces

#INPUT
my_str = input('Test: ')

#CALL FUNCTION
new_str = add_spaces(my_str)

#OUTPUT
print(new_str)