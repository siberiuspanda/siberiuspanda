"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
#IMPORT FUNCTION
from functions import sum_digit

#INPUT
my_str = input('Enter Input: ')

#CALL FUNCTION
total = sum_digit(my_str)

#OUTPUT
print(total)