"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
# IMPORT FUNCTION
from functions import driver_license

# GATHER INPUT
correct_answer = ['A', 'C', 'A', 'A', 'D', 'B', 'C', 'A', 'C', 'B', 'A', 'D', 'C', 'A', 'D', 'C', 'B', 'B', 'D', 'A']
student_answer = str(input('Enter a sequence of 20 choices separated by a space, each A-D in Uppercase: '))

student_answer = student_answer.replace(' ', '')
student_answer = list(student_answer)

#CALL FUNCTION
total_correct, total_wrong, list_wrong = driver_license(correct_answer, student_answer)

# OUTPUT
if total_correct >= 15:
    print('You passed your driver license exam')
else:
    print('You failed your driver license exam')
print('#Correct answers = {}, #incorrect answers = {}'.format(total_correct, total_wrong))
print('A list of incorrectly answered questions = {}'.format(list_wrong))
print('To pass the exam you need to score 15 out of 20')