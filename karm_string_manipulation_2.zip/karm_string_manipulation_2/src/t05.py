"""
-------------------------------------------------------
CP104
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2020-11-22"
-------------------------------------------------------
"""
#IMPORT
from functions import is_chain

#INPUT
list_string = ['happy', 'sad', 'said', 'down']

#CALL FUNCTION
chain_check = is_chain(list_string)

#OUTPUT
print("""List: {}
Is the list in the chain? : {}""".format(list_string,chain_check))