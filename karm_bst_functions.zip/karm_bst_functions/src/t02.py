
"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-03-18"
-------------------------------------------------------
"""
from Letter import Letter
from BST_linked import BST
from functions import do_comparisons, comparison_total

bst_1 = BST()
bst_2 = BST()
bst_3 = BST()

DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"

for i in DATA1:
    letter = Letter(i) 
    bst_1.insert(letter)
for i in DATA2:
    letter = Letter(i) 
    bst_2.insert(letter)
for i in DATA3:
    letter = Letter(i) 
    bst_3.insert(letter)
    
for comp in bst_1:
    comp.comparisons = 0
    
for comp in bst_2:
    comp.comparisons = 0
    
    
for comp in bst_3:
    comp.comparisons = 0
    
    
fh = open('miserables.txt', 'r')
do_comparisons(fh, bst_1)
do_comparisons(fh, bst_2)
do_comparisons(fh, bst_3)
    
    
total_1 = comparison_total(bst_1)
total_2 = comparison_total(bst_2)
total_3 = comparison_total(bst_3)


print('Comparing by order: {}'.format(DATA1))
print('Total Comparisons: {}'.format(total_1))
print('------------------------------------------------------------')
print('Comparing by order: {}'.format(DATA2))
print('Total Comparisons: {}'.format(total_2))
print('------------------------------------------------------------')
print('Comparing by order: {}'.format(DATA3))
print('Total Comparisons: {}'.format(total_3))
