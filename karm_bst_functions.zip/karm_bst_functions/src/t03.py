
"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
__updated__ = "2021-03-18"
-------------------------------------------------------
"""
from functions import do_comparisons, comparison_total, letter_table
from Letter import Letter
from BST_linked import BST

bst_3 = BST()

DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"

for data in DATA3:
    letter = Letter(data)
    bst_3.insert(letter)

for element in bst_3:
    element.comparisons = 0

fh = open('miserables.txt', 'r')
do_comparisons(fh, bst_3)    

total_3 = comparison_total(bst_3)


letter_table(bst_3)