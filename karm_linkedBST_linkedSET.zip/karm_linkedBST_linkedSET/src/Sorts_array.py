"""
-------------------------------------------------------
Array versions of various sorts - Exam
-------------------------------------------------------
Author:  Mikhail Karmali
ID:      201495920
Email:   karm5920@mylaurier.ca
Section: CP164 B
__updated__ = "2021-04-18"
-------------------------------------------------------
"""


class Sorts:
    # The Sorts

    @staticmethod
    def radix_string_sort(strings):
        """
        -------------------------------------------------------
        Performs a string radix sort.
        Use: Sorts.radix_string_sort(strings)
        -------------------------------------------------------
        Parameters:
            strings - an array of strings (list of str)
        Returns‌​​​‌‌​​:
            None
        -------------------------------------------------------
        """
        x = len(strings)
        if x > 0 :
            maxlen = ''
            for i in strings:
                if len(i) > len(maxlen):
                    maxlen = i
            output_list = []
            buckets = [output_list] * 26 
            
            for i in range(len(maxlen)):
                for j in range(x):
                    i = len(maxlen) - 1
                    if i > len(strings[j]):
                        e = j[i:i+1]
                    else:
                        e = i
                    if len(buckets[e]) > 0:
                        buckets[e].append(strings[j])
                    else:
                        buckets[e] = [strings[j]]
                k = 0 
                for c in range(26):
                    while len(buckets[c]) > 0:
                        strings[k] = buckets[c].pop(0)
                        k = k+1
        return

    @staticmethod
    def is_sorted(a):
        """
        -------------------------------------------------------
        Determines whether an array is sorted or not.
        Use: b = Sorts.is_sorted(a)
        -------------------------------------------------------
        Parameters:
            a - an array of comparable elements (?)
        Returns‌​​​‌‌​​:
            srtd - True if contents of a are sorted,
                False otherwise (boolean)
       -------------------------------------------------------
        """
        srtd = True
        n = len(a)
        i = 0

        while srtd and i < n - 1:

            if a[i].lower() <= a[i + 1].lower():
                i += 1
            else:
                srtd = False
        return srtd
