"""
-------------------------------------------------------
Simple Set testing - Exam
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Section: CP164 B
__updated__ = "2021-04-19"
-------------------------------------------------------
"""
# Imports
from Set_linked import Set

# Constants
SEP = '-' * 60

# Testing
source = Set()

print(SEP)
empty = source.is_empty()
print("Set is empty: {}".format(empty))
length = len(source)
print("Set length: {}".format(length))

print(SEP)
print("Add values 0 (front) - 5 (end)")
for i in range(6):
    source.add(i)

empty = source.is_empty()
print("Set is empty: {}".format(empty))
length = len(source)
print("Set length: {}".format(length))

print("Values in set (front to end):")

for v in source:
    print(v, end=", ")
print()

print(SEP)
print("Attempt to add a value already in set (1)")
added = source.add(1)
print("Added: {}".format(added))

print(SEP)
print("Remove 3")
removed = source.remove(3)
print("Removed:", removed)
print("Values in set (front to end):")

for v in source:
    print(v, end=", ")
print()

print(SEP)
print("Remove Front")
removed = source.remove_front()
print("Removed:", removed)
print("Values in set (front to end):")

for v in source:
    print(v, end=", ")
print()

print(SEP)
print('LINEAR SEARCH')
key = 7
a = Set()
a.add(5)
a.add(3)
a.add(1)
a.add(2)

prev, curr = a._linear_search(key)

if prev is None:
    print('None')
else:
    print(prev._value)
if curr is None:
    print('None')
else:
    print(curr._value)
print(SEP)
print('COMBINE')
source1 = Set()
source2 = Set()
target = Set()
source1.add(1)
source1.add(2)
source1.add(3)
source2.add(3)
source2.add(4)
source2.add(5)

for t in source1:
    print(t)
print()
for s in source2:
    print(s)
    
target.combine(source1,source2)
print()
for i in target:
    print(i)
    
print(SEP)
print('SPLIT ALT')

c = Set()
c.add(1)
c.add(2)
c.add(3)
c.add(6)
c.add(9)
c.add(11)
c.add(8)

print()
for i in c:
    print(i)

target1, target2 = c.split_alt()

print()

for x in target1:
    print(x)

print()

for y in target2:
    print(y)
    
print(SEP)
print('ISDISJOINT')

source = Set()
a = Set()
a.add(1)
a.add(2)
a.add(3)
source.add(4)
source.add(5)
source.add(6)

print()
for x in a:
    print(x)

print()

for y in source:
    print(y)

print()

disjoint = a.isdisjoint(source)

print(disjoint)

print(SEP)
    


